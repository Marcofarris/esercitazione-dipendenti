import { Injectable } from '@angular/core';
import { CDipendente } from './c-dipendente';

@Injectable({
  providedIn: 'root'
})
export class SDipendenteService {
  Lista: CDipendente[] = [new CDipendente(0, 'Marco', 'Far', "1997", "marco@gm.it")]

  id: number;

  constructor() {
    this.id = 0;
  }

  addDip(dip: any) {
    this.id++;
    this.Lista.push(new CDipendente(this.id, dip[0], dip[1], dip[2], dip[3]))
  }

  getList(){
    return this.Lista
  }

  selectDip(num:number){
    for (let index = 0; index < this.Lista.length; index++) {
      if(this.Lista[index].id == num){
        return this.Lista[index]
      }
      
    }

  }

  
}
