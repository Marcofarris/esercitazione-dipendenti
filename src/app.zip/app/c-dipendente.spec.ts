import { CDipendente } from './c-dipendente';

describe('CDipendente', () => {
  it('should create an instance', () => {
    expect(new CDipendente()).toBeTruthy();
  });
});
